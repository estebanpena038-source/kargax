# 09_GUION_DEMO

## Objetivo de la demo

No demostrar todas las pantallas.

El objetivo es que el cliente diga:

> “Sí, este problema lo tenemos. Probemos en una ruta.”

## Duración ideal

30 a 35 minutos.

## Antes de la demo

Investigar:

- Qué vende o transporta la empresa.
- Ciudades donde opera.
- Si tiene flota propia o terceriza.
- Si tiene bodegas.
- Si hace ecommerce/entregas.
- Quién podría decidir.

Preparar hipótesis:

> Creo que {{Empresa}} puede tener dolor en {{evidencias/rutas/flota/bodega/costos}}.

## Agenda

1. Contexto rápido — 3 minutos.
2. Diagnóstico — 7 minutos.
3. Demo enfocada — 15 minutos.
4. ROI y piloto — 7 minutos.
5. Cierre — 3 minutos.

## Apertura

> Gracias por el espacio. No voy a hacer una demo larga ni genérica. Quiero entender cómo están controlando rutas, evidencias, conductores y costos; luego le muestro un flujo específico y cerramos si tiene sentido un piloto.

## Preguntas de diagnóstico

### Operación

- ¿Cuántas entregas o viajes manejan al mes?
- ¿Tienen flota propia, transportadores terceros o mezcla?
- ¿Cuántas bodegas o puntos de despacho tienen?
- ¿Qué rutas o ciudades son más críticas?

### Evidencia

- ¿Cómo reciben hoy fotos, firmas o soportes?
- ¿Dónde queda la evidencia?
- ¿Qué pasa cuando el cliente reclama?
- ¿Cuánto tiempo tarda el equipo en encontrar un soporte?

### Conductores

- ¿Cómo asignan viajes?
- ¿Cómo reportan novedades?
- ¿Cómo liquidan gastos o pagos?
- ¿Tienen problemas de actualización de estado?

### Costos

- ¿Saben costo por ruta?
- ¿Saben margen por cliente?
- ¿Qué costos aparecen tarde?
- ¿Qué decisiones toman con reportes?

## Transición a demo

> Con lo que me cuenta, el problema principal no parece ser mover la mercancía. El problema es controlarla. Le muestro cómo KargaX organiza ese flujo.

## Flujo de demo recomendado

### Pantalla 1: Torre de control / Dashboard

Decir:

> Esta es la vista que debería tener gerencia: qué viajes están activos, cuáles están en riesgo, qué evidencias faltan y dónde hay novedades.

Mostrar:

- Viajes activos.
- Estados.
- Novedades.
- Métricas.

### Pantalla 2: Crear o asignar viaje

Decir:

> Aquí se crea la operación: origen, destino, fecha, carga, conductor, requisitos y costo.

Mostrar:

- Origen/destino.
- Tipo de carga.
- Vehículo.
- Valor/costo.
- Conductor asignado.

### Pantalla 3: Conductor / seguimiento

Decir:

> El conductor no debe mandar todo por WhatsApp. Debe actualizar el viaje, subir evidencia y reportar novedades desde un flujo simple.

Mostrar:

- Estado.
- Evidencia.
- Novedad.
- Fotos/firma/PIN si aplica.

### Pantalla 4: Evidencia digital

Decir:

> Esta es una de las partes más valiosas: cada entrega queda con evidencia asociada al viaje, no perdida en chats.

Mostrar:

- Foto.
- Firma.
- PIN.
- GPS.
- Novedad/rechazo.

### Pantalla 5: Bodega / despacho

Decir:

> Si la operación sale de bodega, KargaX conecta despacho con ruta y evidencia final. La operación no se rompe al salir del muelle.

Mostrar:

- Bodega.
- Inventario/ítems.
- Despacho.
- Cita.
- Cargue.

### Pantalla 6: Costos y reportes

Decir:

> La gerencia necesita saber qué pasó y cuánto costó. Aquí se puede medir costo, margen, novedades y desempeño por ruta/conductor.

Mostrar:

- Reporte por ruta.
- Costos.
- Incidencias.
- Cumplimiento.

## Preguntas de cierre durante la demo

- ¿Este flujo se parece a algo que hoy manejan manualmente?
- ¿Dónde ve más dolor: evidencia, rutas, conductores, bodega o costos?
- ¿Qué parte tendría más impacto si la probamos 15 días?
- ¿Quién más debería ver esto para aprobar un piloto?

## Propuesta de piloto en la demo

> Mi recomendación no es implementar todo. Tomemos {{alcance}}:
>
> - {{número}} rutas
> - {{número}} conductores
> - {{número}} días
> - {{métrica principal}}
>
> Al final entregamos un reporte con evidencias, novedades, tiempos y aprendizajes.

## Cierre final

> Si le parece, el siguiente paso no es otra demo. Es definir el piloto: alcance, usuarios, rutas, métrica y fecha de inicio. ¿Quién debe estar en esa decisión?

## Cierre si hay interés

> Perfecto. Le envío hoy un resumen de piloto de una página y agendamos configuración.

## Cierre si hay duda

> Tiene sentido. Para reducir riesgo, lo hacemos pequeño: una ruta o cinco conductores. Si no genera valor, no seguimos. ¿Qué operación sería buena para probar?

## Cierre si piden tiempo

> Claro. Para no dejarlo abierto, ¿qué le parece si agendamos una revisión de 15 minutos el {{día}} y ahí decide si avanzamos o no?

## Checklist de demo

- Dolor confirmado.
- Decisor identificado.
- Alcance del piloto definido.
- Métrica acordada.
- Fecha tentativa.
- Próximo paso calendarizado.
