# 06_OFERTA_COMERCIAL

## Objetivo de venta

Vender KargaX como una solución de control operativo premium, no como una app barata.

La oferta debe lograr tres cosas:

1. Reducir riesgo para el cliente.
2. Obligar a definir un dolor concreto.
3. Crear camino natural a pago mensual.

---

# Oferta 1: Piloto gratuito

## Nombre

**Piloto KargaX Control Operativo — 15 días**

## Duración

15 días.

Usar 30 días solo si el cliente tiene bodega + flota + varios usuarios.

## Qué incluye

- 1 flujo operativo.
- Hasta 5 conductores o usuarios operativos.
- Hasta 25 viajes/entregas.
- Registro de rutas/viajes.
- Evidencia de cargue/entrega.
- Novedades operativas.
- Tablero básico de seguimiento.
- 1 sesión de onboarding.
- 1 reunión de revisión.
- 1 reporte final.

## Qué no incluye

- Integraciones con ERP/TMS/WMS.
- Desarrollo a la medida.
- Soporte 24/7.
- Migración histórica.
- Custodia financiera directa.
- Automatizaciones complejas.
- Operación de todos los clientes/rutas de la empresa.

## Qué debe entregar el cliente

- 1 sponsor interno.
- 1 responsable operativo.
- Lista de rutas o entregas piloto.
- Lista de usuarios/conductores.
- Criterio claro de éxito.
- Compromiso de reunión final.

## Métricas a medir

- % de entregas con evidencia completa.
- Tiempo promedio de actualización de estado.
- Número de novedades registradas.
- Tiempo invertido en seguimiento manual.
- Rutas con costo visible.
- Reclamos o incidencias con soporte.
- Satisfacción del equipo operativo.

## Cómo se convierte en pago

Antes de iniciar:

> Si el piloto demuestra mejora en visibilidad, evidencia o control de novedades, el siguiente paso es un plan mensual desde COP {{precio}}.

Cierre al final:

> Vimos que {{métrica}} mejoró y que el equipo ahora tiene {{beneficio}}. Para mantener esto funcionando, el plan recomendado es {{plan}} por {{precio}} mensual. ¿Lo activamos desde el lunes?

## Cuándo usarlo

- Cliente mediano con buen fit.
- Necesitas caso de éxito.
- Hay sponsor serio.
- Puedes controlar el alcance.

## Cuándo no usarlo

- Cliente pide demasiado sin compromiso.
- No hay sponsor.
- Quiere integraciones desde día uno.
- Solo quiere “curiosear”.

---

# Oferta 2: Piloto pago barato

## Nombre

**Piloto KargaX Founder-Led — 30 días**

## Precio recomendado

Tres opciones:

- COP 350.000: piloto muy pequeño, 1 ruta, hasta 10 viajes.
- COP 750.000: piloto estándar, hasta 50 viajes o 10 conductores.
- COP 1.500.000: piloto premium, bodega + flota + reporte ejecutivo.

Recomendación: empezar ofreciendo **COP 750.000** para no sonar como hobby.

## Duración

30 días.

## Qué incluye

- Todo lo del piloto gratuito.
- Configuración asistida.
- Reunión semanal.
- Reporte de valor.
- Priorización de mejoras.
- Soporte founder-led.
- Plantilla de decisión para pasar a mensual.

## Por qué conviene cobrar algo

- Filtra curiosos.
- Crea compromiso.
- Obliga al cliente a asignar gente.
- Posiciona KargaX como producto serio.
- Te da feedback de clientes que realmente valoran el problema.

## Cómo venderlo

> No cobramos el piloto como licencia completa. Lo cobramos para garantizar configuración, acompañamiento y reporte de valor. Si el piloto se convierte en plan mensual, podemos descontar el valor del primer mes.

## Conversión

Opción agresiva:

> Si pasan a plan mensual antes del día 30, el valor del piloto se abona al primer mes.

---

# Oferta 3: Plan mensual B2B

Los precios recomendados aquí son comerciales, pensados para vender como SaaS B2B premium en Colombia. El repo tiene migraciones con precios COP, pero aparecen versiones comerciales distintas a lo largo de las migraciones; por eso estos precios deben tratarse como recomendación de salida comercial, no como “precio técnico definitivo”.

## Plan Básico — Control Operativo

**Precio recomendado:** COP 799.000 / mes + IVA si aplica.

## Para quién

- Distribuidora regional.
- Empresa con flota pequeña.
- Ferretería grande.
- Operador con una bodega.
- Empresa que quiere ordenar rutas y evidencias.

## Incluye

- 1 bodega o centro operativo.
- Hasta 5 usuarios internos.
- Hasta 5 conductores.
- Hasta 150 viajes/entregas al mes.
- Registro de rutas.
- Evidencia digital.
- Novedades.
- Reporte operativo básico.
- Soporte por email/WhatsApp en horario laboral.

## Cuándo usarlo

- Primer cliente pago.
- Operaciones pequeñas pero con dolor real.
- Cuando el cliente no requiere analítica avanzada.

---

## Plan Crecimiento — Torre de Control

**Precio recomendado:** COP 1.800.000 / mes + IVA si aplica.

## Para quién

- Operador logístico mediano.
- Distribuidora con varias rutas.
- Empresa con flota propia.
- Empresa con varias bodegas o equipos.

## Incluye

- Hasta 5 bodegas.
- Hasta 20 usuarios internos.
- Hasta 20 conductores/flota.
- Hasta 500 viajes/entregas al mes.
- Bodegas, inventario ligero y despachos.
- Evidencia digital avanzada.
- Flota privada.
- Novedades.
- Reportes ejecutivos.
- Control de costos por ruta.
- Reunión mensual de mejora.

## Cuándo usarlo

- Cliente con operación diaria.
- Necesita reportes.
- Tiene más de una persona en operaciones.
- Quiere control de flota y bodega.

---

## Plan Enterprise — Control Logístico Premium

**Precio recomendado:** desde COP 4.500.000 / mes + implementación.

## Setup recomendado

COP 3.000.000 a COP 15.000.000 según alcance.

## Para quién

- Transportadora mediana/grande.
- 3PL multi-cliente.
- Retail con varias ciudades.
- Empresa con operación nacional.
- Grupo empresarial.

## Incluye

- Usuarios según alcance.
- Bodegas según alcance.
- Flota privada avanzada.
- Evidencia avanzada.
- Control tower.
- Reportes ejecutivos.
- Control de margen.
- Roles y permisos.
- Acompañamiento premium.
- Roadmap de integraciones.
- SLA negociado.

## Cuándo usarlo

- Hay sponsor ejecutivo.
- Hay presupuesto.
- El dolor está asociado a dinero real.
- Requieren soporte y parametrización.

---

# Regla de pricing

No cobres por “pantallas”.

Cobra por:

- Control operativo.
- Evidencia verificable.
- Reducción de reprocesos.
- Menos tiempo de seguimiento manual.
- Mejor respuesta al cliente.
- Visibilidad de costos y margen.
- Auditoría de conductores/transportadores.

## Argumento de ROI

Fórmula simple:

> Ahorro mensual = horas operativas ahorradas + reclamos evitados + reprocesos reducidos + mejor control de costos.

Ejemplo para explicar:

> Si su equipo pierde 2 horas diarias persiguiendo evidencias y estados, son 40 horas al mes. Si además cada entrega fallida/reclamada le cuesta dinero en reproceso, KargaX se paga con evitar una fracción de ese desorden.

## Cierre comercial

> No tiene que creerme. Hagamos el piloto con una operación limitada, medimos evidencia, tiempos y novedades, y decidimos con datos.
