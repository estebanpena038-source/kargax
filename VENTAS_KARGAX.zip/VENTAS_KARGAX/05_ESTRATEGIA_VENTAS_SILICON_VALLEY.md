# 05_ESTRATEGIA_VENTAS_SILICON_VALLEY

## 1. Objetivo de venta

Conseguir los primeros pilotos reales de KargaX con empresas que ya mueven mercancía y tienen dolor visible de control operativo.

Meta inicial:

- 100 empresas contactadas.
- 20 conversaciones.
- 8 reuniones.
- 3 pilotos.
- 1 cliente pago.
- 1 carta de intención/LOI.

## 2. Posicionamiento premium

No vender KargaX como “una app de envíos”.

Venderlo así:

> KargaX es el sistema operativo para empresas que necesitan controlar rutas, conductores, flota privada, bodegas, evidencias, costos y novedades desde una sola plataforma.

Mensaje premium:

> Hoy muchas empresas mueven mercancía, pero no controlan realmente su operación. KargaX les da una torre de control para saber qué salió, quién lo llevó, dónde está, qué evidencia existe, qué novedad ocurrió y cuánto costó.

Frase anti-spam:

> No estoy vendiendo una app genérica. Estoy buscando 3 empresas con operación logística real para validar un piloto founder-led de control operativo.

## 3. Cliente ideal inicial

Prioridad 1:

- Distribuidoras regionales.
- Empresas con flota propia.
- Operadores logísticos medianos.
- Empresas de alimentos.
- Ferreterías/materiales.
- Empresas con bodegas.

Evitar al inicio:

- Corporativos muy grandes sin contacto interno.
- Empresas con procesos de compras lentos.
- Marketplaces con soluciones internas muy maduras.
- Empresas que no tengan volumen real.

## 4. Dolor principal

El pitch debe entrar por dinero y control:

> El problema no es mover mercancía. El problema es perder control: rutas por WhatsApp, evidencias perdidas, costos invisibles, conductores sin trazabilidad y reportes manuales.

## 5. Pitch de 30 segundos

> Hola, soy fundador de KargaX. Estamos ayudando a empresas que mueven mercancía a controlar rutas, conductores, evidencias, bodegas, costos y novedades desde una sola plataforma. No buscamos reemplazar toda la operación de una vez: proponemos un piloto de 15 a 30 días con una ruta, una bodega o una flota pequeña para medir visibilidad, evidencia y reducción de reprocesos.

## 6. Pitch de 2 minutos

> KargaX nace de un problema muy común en logística: muchas empresas tienen camiones, bodegas y clientes, pero la operación diaria sigue viviendo en WhatsApp, Excel y llamadas. Eso genera evidencias perdidas, retrasos, rutas sin control, liquidaciones discutidas y costos que nadie ve hasta final de mes.
>
> KargaX centraliza esa operación: empresa, conductor, ruta, bodega, evidencia, novedad, costo y reporte. La empresa puede publicar o asignar viajes, controlar flota privada, registrar evidencias de cargue y entrega, manejar novedades, revisar costos y tener un tablero ejecutivo.
>
> No le estoy proponiendo cambiar todo su sistema. Le propongo probarlo en un flujo real durante 15 a 30 días: una ruta, una bodega o 5 conductores. Si no mejora visibilidad, evidencia o control, no seguimos. Si funciona, lo escalamos por módulos.

## 7. Mensaje de WhatsApp

> Hola {{Nombre}}, soy {{Tu nombre}}, fundador de KargaX.
>
> Estamos ayudando a empresas que mueven mercancía a controlar rutas, conductores, evidencias de entrega, costos y novedades sin depender tanto de WhatsApp, Excel y llamadas.
>
> Vi que {{Empresa}} tiene operación logística/distribución. ¿Tiene sentido mostrarle un piloto corto de 15 días para controlar una ruta o flota pequeña?

## 8. Cold email corto

Asunto: Piloto para controlar rutas y evidencias en {{Empresa}}

Hola {{Nombre}},

Soy {{Tu nombre}}, fundador de KargaX.

Estamos construyendo una plataforma para que empresas con operación logística controlen rutas, conductores, bodegas, evidencias de entrega, novedades y costos desde un solo lugar.

Vi que {{Empresa}} mueve mercancía y creo que podríamos probar KargaX en un piloto pequeño: una ruta, una bodega o una flota limitada durante 15 a 30 días.

La idea no es reemplazar su operación actual, sino medir si podemos reducir desorden, evidencias perdidas y falta de visibilidad.

¿Le puedo mostrar el flujo en 20 minutos esta semana?

{{Tu nombre}}

## 9. LinkedIn outreach

> Hola {{Nombre}}, vi que trabajas en operaciones/logística en {{Empresa}}. Estoy construyendo KargaX, una plataforma para controlar rutas, conductores, evidencias, bodegas y costos logísticos. Estoy buscando 3 empresas para pilotos founder-led de 15 a 30 días. ¿Tiene sentido que conversemos?

## 10. Guion de llamada

Inicio:

> Hola {{Nombre}}, soy {{Tu nombre}}, fundador de KargaX. Le escribí porque estamos ayudando a empresas que mueven mercancía a ordenar rutas, conductores, evidencias y costos. No quiero quitarle mucho tiempo: ¿usted ve temas de logística/operaciones en {{Empresa}}?

Descubrimiento:

> ¿Cómo coordinan hoy las rutas?
> ¿Las evidencias de entrega quedan en algún sistema o en WhatsApp?
> ¿Quién controla novedades y rechazos?
> ¿Saben cuánto cuesta realmente cada ruta o cliente?
> ¿Tienen flota propia, tercerizada o mixta?
> ¿Cuál es el problema más incómodo hoy: visibilidad, evidencia, costos, conductores o reportes?

Dolor:

> Por lo que me cuenta, el dolor no es solo transporte; es control operativo. Ahí es donde KargaX puede ayudar.

Cierre de reunión:

> Le propongo algo muy simple: 20 minutos, le muestro el flujo y si no ve valor lo dejamos ahí. Si le hace sentido, diseñamos un piloto con una ruta o flota pequeña.

## 11. Guion de reunión/demo

Estructura:

1. 5 minutos: contexto del cliente.
2. 5 minutos: mapa de dolor.
3. 10 minutos: demo del flujo.
4. 5 minutos: ROI y métricas.
5. 5 minutos: piloto y cierre.

Preguntas de alto nivel:

- ¿Cuántos viajes/entregas hacen al mes?
- ¿Cuántos conductores o transportadores usan?
- ¿Cuántas bodegas o puntos de despacho tienen?
- ¿Qué porcentaje de evidencias llega tarde o incompleta?
- ¿Qué pasa cuando un cliente reclama una entrega?
- ¿Cómo liquidan viajes o gastos?
- ¿Qué reportes necesita gerencia?

Demo sugerida:

- Crear viaje/ruta.
- Asignar conductor.
- Mostrar evidencia de cargue/entrega.
- Registrar novedad.
- Ver estado operativo.
- Ver reporte/costos.
- Cerrar con piloto.

Cierre:

> Con lo que vimos, yo no intentaría implementar todo. Tomaría {{ruta/flota/bodega}} y mediría 4 cosas: evidencia completa, tiempo de actualización, número de novedades y visibilidad para gerencia. Si eso mejora, seguimos.

## 12. Oferta de piloto

Piloto fundador:

- 15 días para empresas pequeñas/medianas.
- 30 días si hay bodega/flota y más usuarios.
- 1 flujo operativo.
- 1 sponsor interno.
- 1 reunión semanal.
- 1 reporte final.

Condición:

> El piloto no es consultoría gratis indefinida. Debe tener alcance, métrica y fecha de decisión.

## 13. Cómo pedir LOI

Después de la demo o piloto:

> {{Nombre}}, si KargaX logra ayudarles a controlar {{dolor específico}} y el piloto muestra mejora en {{métrica}}, ¿estarían dispuestos a firmar una carta de intención para avanzar a un plan pago después del piloto?

Texto simple de LOI:

> Esta carta expresa el interés de {{Empresa}} en evaluar KargaX mediante un piloto operativo de {{duración}} para {{alcance}}. Si el piloto demuestra valor operativo en {{métricas}}, las partes explorarán un contrato comercial mensual.

## 14. Cómo cerrar el primer cliente

No cierres “contrato grande”.

Cierra:

> Plan mensual de control operativo.

Ejemplo:

> Para mantenerlo simple: después del piloto, el plan sería COP {{precio}} mensual por {{alcance}}, con soporte founder-led por los primeros 60 días. Si en dos meses no está generando valor, lo revisamos. ¿Avanzamos?

## 15. Cómo cobrar después del piloto

Modelo:

- Mes 1-2: onboarding + acompañamiento.
- Mes 3+: plan mensual.
- Expansión por módulos.

Regla:

> No cobres por usuario solamente. Cobra por operación controlada: rutas, bodegas, conductores, evidencias, reportes y ahorro de reprocesos.

## 16. Cómo evitar que te ignoren

No escribir:

> “Te presento una plataforma logística innovadora.”

Sí escribir:

> “Vi que manejan distribución/rutas. ¿Hoy las evidencias de entrega les quedan centralizadas o siguen llegando por WhatsApp?”

Seguimientos:

1. Dolor.
2. Caso de uso.
3. Piloto concreto.
4. Cierre elegante.

## 17. Cómo sonar como fundador serio

Usa este lenguaje:

- “Piloto controlado.”
- “Sponsor operativo.”
- “Métrica de éxito.”
- “Alcance limitado.”
- “Reporte de valor.”
- “Decisión al día 15/30.”
- “No reemplazamos su operación completa de entrada.”
- “Validamos con datos.”

Evita:

- “Estoy empezando.”
- “La app está en MVP.”
- “Mira si te gusta.”
- “Te la dejo gratis a ver.”
- “Ayúdame probándola.”

Frase founder premium:

> Estamos abriendo cupos para 3 pilotos con empresas que tengan operación logística real. No buscamos volumen de demos; buscamos operaciones donde podamos medir impacto en trazabilidad, evidencia y costos.
