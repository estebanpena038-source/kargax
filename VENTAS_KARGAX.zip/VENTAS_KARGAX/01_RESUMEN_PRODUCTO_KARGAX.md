# 01_RESUMEN_PRODUCTO_KARGAX

Fecha de análisis: 2026-06-12

## Fuente analizada

El usuario pegó un placeholder de repo, pero el repositorio real encontrado y analizado fue:

- Repo: `https://github.com/estebanpena038-source/kargax`
- README raíz: `https://github.com/estebanpena038-source/kargax/blob/main/README.md`
- Frontend principal: `https://github.com/estebanpena038-source/kargax/tree/main/frontend`
- Rutas de la app: `https://github.com/estebanpena038-source/kargax/tree/main/frontend/src/app`
- Migraciones Supabase: `https://github.com/estebanpena038-source/kargax/tree/main/supabase/migrations`

## 1. Qué es KargaX en una frase poderosa

**KargaX no es solo un software de envíos. Es el sistema operativo para que empresas logísticas controlen su operación, sus costos, sus rutas, sus evidencias, sus conductores, sus bodegas y su crecimiento desde una sola plataforma.**

Versión comercial más corta:

**KargaX es la torre de control SaaS para empresas que mueven mercancía y quieren dejar de operar rutas, bodegas, conductores, evidencias y pagos desde WhatsApp, Excel y llamadas.**

## 2. Qué problema real resuelve

KargaX resuelve un problema muy concreto: **la operación logística se rompe cuando la información queda dispersa**.

El dolor real no es “necesito una app”. El dolor es:

- No saber qué viaje está en riesgo.
- No tener evidencia confiable de cargue o entrega.
- Perder tiempo preguntando por WhatsApp “¿dónde va el conductor?”.
- No saber cuánto costó realmente una ruta.
- No saber el margen por cliente, ruta, conductor o transportador.
- No poder auditar novedades, rechazos, fotos, firmas, tiempos y soportes.
- Tener bodegas, inventario, despachos y transporte en sistemas separados o manuales.
- Hacer liquidaciones y pagos sin trazabilidad suficiente.
- Depender de llamadas cuando un cliente exige respuesta ejecutiva.

## 3. Para qué tipo de empresa sirve

KargaX sirve para empresas que tienen operación logística real, especialmente:

- Empresas de transporte de carga.
- Operadores logísticos pequeños y medianos.
- Empresas con flota propia.
- Distribuidoras regionales.
- Empresas con bodegas o centros de distribución.
- Retailers con entregas.
- Ecommerce B2B.
- Ferreterías, construcción y materiales.
- Alimentos y bebidas no alcohólicas.
- Farma, insumos médicos y distribución sensible.
- Empresas que aún coordinan con Excel, WhatsApp, llamadas y documentos dispersos.

## 4. Qué módulos existen según repo/código

### Marketplace de carga

Comprobado en migraciones:

- Tabla `cargo_offers` para ofertas de carga con empresa, camionero asignado, estado, tipo de carga, peso, dimensiones, origen, destino, fechas, monto, método de pago, requisitos, experiencia, licencias, seguros, vistas y aplicaciones.
- Estados: `draft`, `active`, `in_progress`, `completed`, `cancelled`, `expired`.
- Aplicaciones de camioneros a ofertas con estado `pending`, `accepted`, `rejected`, `withdrawn`.
- Contador automático de aplicaciones.
- Políticas RLS para empresas y camioneros.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/002_cargo_offers.sql
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/003_offer_applications.sql

### Usuarios, empresas, camioneros y roles

Comprobado:

- Tipos de usuario: `trucker`, `business`, `admin`.
- Perfil de empresa con nombre, NIT, industria, dirección, ciudad, departamento, rating y total shipments.
- Perfil de camionero con licencia, experiencia, tipos de vehículo, zonas de servicio, rating, disponibilidad y ubicación actual.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/frontend/supabase_schema.sql

### Mensajería y conversaciones

Comprobado:

- Conversaciones entre participantes.
- Conversación asociada opcionalmente a una oferta.
- Último mensaje, fecha, contadores de no leídos.
- Mensajes de tipo texto, imagen, archivo o sistema.
- Adjuntos.
- Funciones para marcar mensajes como leídos y contar no leídos.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/006_conversations.sql
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/007_messages.sql

### Wallet, pagos y transacciones

Comprobado:

- Billeteras por usuario, principalmente camioneros.
- Saldo pendiente, saldo disponible, total ganado, total retirado y viajes completados.
- Datos bancarios para retiro.
- Transacciones con historial inmutable y audit trail.
- Tipos: pago por viaje, pago pendiente, fee de plataforma, retiro, devolución, ajuste, bono.
- Pagos con pasarelas externas: Wompi, Mercado Pago, Stripe y manual.
- Confirmación de pago que mueve valores a saldo pendiente del camionero y cambia el viaje a `in_progress`.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/010_wallets.sql
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/011_transactions.sql
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/012_payments.sql

Nota crítica de venta: **el repo indica que wallet debe venderse como ledger operativo, no como banco ni custodia financiera propia.** Para mover o custodiar dinero real se deben usar pasarelas o aliados regulados.

### Evidencia digital, picking, GPS, fotos y trazabilidad

Comprobado:

- Sistema de picking digital.
- Verificación GPS en origen y destino.
- Fotos de evidencia.
- Trazabilidad completa desde carga hasta entrega.
- Eventos de picking: llegada a origen, inicio de cargue, item cargado, novedad, cargue completado, llegada a destino, descarga, item entregado, item rechazado, foto agregada.
- Auditoría con quién, qué, cuándo, dónde, cantidad, notas, motivo de rechazo, fotos, GPS y metadata.
- Campos de fotos generales de viaje, notas de cargue y descargue.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/018_enhanced_picking.sql

### Bodegas, inventario y SaaS

Comprobado:

- Planes SaaS y límites.
- Bodegas con código, nombre, ciudad, departamento, dirección, estado y modo operativo.
- Miembros de bodega, muelles, contactos, clientes, ubicaciones, SKUs, saldos de stock, citas, recibos y despachos.
- Planes con inventario, ubicaciones, recibos, despachos, analítica, API/webhooks y multi-cliente 3PL.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/023_warehouse_management_and_saas.sql

### Flota privada B2B

Comprobado:

- Invitaciones para vincular conductores a una empresa.
- Miembros de flota privada.
- Asignación directa de viajes.
- Límites de conductores por plan.
- Separación entre viáticos/gastos y flete.
- Evidencias de firma digital.
- Campos de viaje privado: `is_private_fleet`, conductor privado, viáticos, pago de flete, confirmación.
- Modos de compensación: salario sin pago por viaje, pago por viaje, solo gastos, pago por viaje + gastos.
- Política de liberación de gastos: aceptación, PIN de cargue, POD de entrega o manual.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/035_private_fleet_b2b.sql
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/043_private_fleet_dispatch_control_tower.sql

### Payroll / nómina operativa de flota privada

Comprobado:

- Configuración de salario mensual por conductor privado.
- Día de nómina.
- Corridas de nómina.
- Ítems por conductor.
- Estados de fondeo/liberación.
- Nota técnica del repo: KargaX mantiene ledger y workflow; los fondos reales deben moverse por aliados regulados.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/048_private_fleet_payroll.sql

### Piloto comercial, planes y límites

Comprobado:

- Migración comercial para Colombia.
- Launch Pilot de 60 días.
- Plan gratuito limitado después de expiración.
- Precios en COP.
- Comisión de marketplace.
- Flota privada sin fee de marketplace.
- Workspace CEO/holding para empresas.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/047_launch_pilot_pricing_and_limits.sql

### Control de margen / última milla

Comprobado:

- Módulo de carriers de última milla.
- Lanes/rutas de última milla.
- Contratos y eventos de contrato.
- Observaciones de costos.
- Scorecards de proveedor.
- Recomendaciones de renegociación.
- Análisis de margen.

Fuente:
- https://github.com/estebanpena038-source/kargax/blob/main/supabase/migrations/20260527_last_mile_margin_control.sql

## 5. Qué módulos parecen más vendibles ahora

Orden recomendado para vender pilotos:

### 1. Evidencia digital + POD + novedades

Es el módulo más fácil de vender porque toca un dolor inmediato: “no tengo prueba clara de entrega/cargue/novedad”.

Promesa:

**“En 15 días dejamos de perseguir evidencias por WhatsApp y centralizamos fotos, firma, PIN, GPS y novedades por viaje.”**

### 2. Flota privada B2B

Muy vendible para empresas con conductores propios.

Promesa:

**“Controla tus conductores, viajes, gastos, evidencias y liquidaciones sin operar la flota desde chats.”**

### 3. Bodegas + despachos + inventario ligero

Vendible para operadores logísticos, distribuidoras y empresas con centros de distribución.

Promesa:

**“Conectamos bodega, despacho y entrega para que el equipo sepa qué salió, quién lo llevó, dónde va y con qué evidencia cerró.”**

### 4. Control de costos/margen por ruta

Muy potente para dueños, CEO y gerentes de operaciones.

Promesa:

**“No solo veas entregas; entiende qué rutas, transportadores y clientes te están dejando o quitando margen.”**

### 5. Marketplace de carga

Es fuerte, pero comercialmente más difícil al inicio porque requiere masa crítica de camioneros/transportadores.

Promesa para MVP:

**“Publica cargas y recibe aplicaciones controladas, con requisitos, trazabilidad y evidencia.”**

## 6. Qué partes son diferenciales

- Combina marketplace, flota privada, bodega, evidencia, pagos y control financiero en una sola arquitectura.
- No se queda solo en tracking; captura evidencia operativa.
- Tiene enfoque B2B real: empresa, camionero, admin, warehouse roles, planes, límites y reportes.
- Incluye wallet/ledger y liquidaciones, pero separa el movimiento real de dinero con pasarelas/aliados.
- El módulo de flota privada permite vender a empresas que no quieren depender de un marketplace.
- El módulo de bodegas permite vender a operadores logísticos y distribuidoras, no solo a transportadoras.
- El control de margen permite hablar con gerentes y dueños en lenguaje de dinero, no solo de tecnología.

## 7. Partes que pueden generar dudas en un cliente

- Madurez de producto: el repo muestra un producto amplio, pero no se verificó operación en producción con clientes reales.
- Integraciones: no queda claro si ya existen integraciones robustas con ERP/TMS/WMS externos.
- Pagos: debe explicarse con cuidado; KargaX no debe prometer ser banco ni custodiar fondos directamente.
- Marketplace: puede requerir oferta y demanda suficiente. Al inicio conviene vender flota privada y control interno.
- Soporte operativo: empresas grandes preguntarán quién responde si hay incidentes.
- Seguridad/compliance: hay RLS y diseño de seguridad, pero un cliente enterprise pedirá evidencias, políticas y pruebas.
- Datos reales: no se verificó volumen real de usuarios, viajes, pagos o transportadores activos.

## 8. Qué se puede vender hoy aunque esté en MVP

### Oferta vendible hoy

**Piloto de Control Operativo Logístico KargaX**

Incluye:

- Registro de rutas/viajes.
- Conductores o transportadores.
- Evidencia de cargue y entrega.
- Novedades operativas.
- Tablero de seguimiento.
- Reporte semanal de rutas, tiempos, incidencias y costos.
- Acompañamiento founder-led.

No vender como:

> “Tenemos todo el sistema completo listo para reemplazar tu operación.”

Vender como:

> “En 15 a 30 días te ayudamos a controlar una parte crítica de tu operación: rutas, evidencias, conductores, novedades y costos. Si el piloto demuestra valor, escalamos por módulos.”

## 9. Posicionamiento recomendado

**KargaX es la capa de control para empresas que ya mueven carga, pero todavía pierden dinero por desorden operativo, falta de evidencia, poca trazabilidad y costos invisibles.**

## 10. Venta inicial recomendada

No empezar por grandes corporativos con ciclos largos. Empezar por:

1. Distribuidoras regionales.
2. Empresas con flota propia.
3. Operadores logísticos medianos.
4. Ferreterías y materiales.
5. Alimentos y distribución B2B.
6. Transportadoras tradicionales que quieren digitalizarse.
7. Farma/insumos médicos con trazabilidad crítica.

La jugada founder-led:

**Piloto pequeño, dolor claro, métrica concreta, cierre rápido, expansión por módulos.**
