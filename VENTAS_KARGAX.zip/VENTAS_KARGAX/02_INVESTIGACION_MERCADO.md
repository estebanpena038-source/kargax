# 02_INVESTIGACION_MERCADO

Fecha: 2026-06-12

## Tesis de mercado

El mercado colombiano y latinoamericano de logística B2B tiene una oportunidad clara para SaaS porque muchas empresas ya tienen volumen, flota, bodegas, transportadores y clientes exigentes, pero todavía operan una parte crítica del día a día con procesos fragmentados.

El problema no es solamente “transportar”. El problema es **controlar**:

- Qué mercancía salió.
- Quién la recogió.
- Dónde está.
- Cuánto costó.
- Qué novedad ocurrió.
- Qué evidencia existe.
- Cuánto margen dejó.
- Quién debe responderle al cliente.

## Señales externas del mercado

### 1. La logística no es estable: los bloqueos y paros afectan operación y abastecimiento

Reuters reportó que en septiembre de 2024 los bloqueos de camioneros en Colombia amenazaron el abastecimiento de alimentos y combustible en grandes ciudades; el conflicto estaba relacionado con el aumento del diésel y su impacto en costos logísticos y competitividad.

Fuentes:
- https://www.reuters.com/world/americas/colombian-government-reaches-deal-with-truckers-suspend-road-blockades-2024-09-06/
- https://www.reuters.com/business/energy/colombias-ecopetrol-says-operations-affected-by-pipeline-attacks-road-blockades-2024-09-04/

Implicación para KargaX:

Cuando hay interrupciones, la empresa que no tiene trazabilidad ni control de rutas queda ciega. KargaX puede venderse como herramienta para responder rápido a cambios, incidentes y riesgo operativo.

### 2. El suroccidente colombiano es vulnerable a desconexiones viales

El País reportó en 2025 problemas recurrentes de la vía Panamericana y riesgo de desabastecimiento en Pasto; también reportó bloqueos hacia Buenaventura con carga represada y afectaciones logísticas/económicas.

Fuentes:
- https://elpais.com/america-colombia/2025-03-20/un-nuevo-derrumbe-en-la-via-panamericana-acentua-la-desconexion-historica-de-pasto-con-el-resto-de-colombia.html
- https://elpais.com/america-colombia/2025-10-18/el-bloqueo-de-las-vias-hacia-buenaventura-se-levanta-luego-de-tres-dias-de-crisis-logistica-economica-y-social.html

Implicación para KargaX:

Para empresas en Cali, Valle, Cauca, Popayán, Santander de Quilichao, Buenaventura y Nariño, la visibilidad de rutas y novedades no es “nice to have”; es defensa operativa.

### 3. La infraestructura vial busca reducir tiempos y costos, pero la empresa igual necesita control interno

El programa de Vías 4G en Colombia fue concebido para mejorar competitividad y reducir costos/tiempos de transporte de carga desde puntos de manufactura hacia puertos de exportación.

Fuente:
- https://es.wikipedia.org/wiki/V%C3%ADas_4G_(Colombia)

Implicación:

Aunque la infraestructura mejore, la empresa todavía necesita software para controlar asignación, evidencia, tiempos, costos, liquidaciones y reportes.

### 4. El estándar competitivo incluye rastreo y puntualidad

El Índice de Desempeño Logístico mide dimensiones como aduanas, infraestructura, facilidad de envíos, calidad logística, rastreo/seguimiento y puntualidad.

Fuente:
- https://es.wikipedia.org/wiki/%C3%8Dndice_de_Desempe%C3%B1o_Log%C3%ADstico

Implicación:

KargaX debe venderse con lenguaje de desempeño logístico: visibilidad, trazabilidad, puntualidad, calidad de servicio y control de costos.

### 5. Las bolsas/marketplaces de carga existen porque hay ineficiencia de capacidad

Una bolsa de carga conecta transportistas, operadores y generadores de carga para aprovechar retornos, capacidad disponible y negociación.

Fuente:
- https://es.wikipedia.org/wiki/Bolsa_de_carga

Implicación:

El marketplace de KargaX tiene sentido, pero no debe ser el primer gancho comercial si aún falta liquidez. La entrada inteligente es SaaS para flota/bodega/evidencia y luego marketplace.

### 6. En transporte terrestre, las pérdidas vienen por falta de control

Un trabajo académico sobre monitoreo IoT de transporte terrestre en Latinoamérica describe que muchos problemas financieros aparecen en transporte terrestre por cambios de ruta, uso de combustible/tiempo y falta de monitoreo de carga/ubicación.

Fuente:
- https://arxiv.org/abs/2307.10945

Implicación:

KargaX debe vender el módulo de control como ahorro de dinero: menos reprocesos, menos rutas sin control, menos evidencias perdidas y mayor capacidad de auditar costos.

## Problemas actuales que KargaX debe atacar

### Dolor 1: Operación en WhatsApp, Excel y llamadas

Síntoma:

- Conductores envían fotos por WhatsApp.
- El jefe de operaciones pide estados uno por uno.
- La evidencia queda mezclada en chats.
- No hay tablero único.
- Excel queda desactualizado.

Mensaje de venta:

**“KargaX convierte WhatsApp, llamadas y Excel en un flujo operativo controlado: ruta, conductor, evidencia, novedad y costo en una sola plataforma.”**

### Dolor 2: Falta de evidencia de entrega

Síntoma:

- Cliente reclama y nadie encuentra la foto.
- El conductor sí entregó, pero no hay prueba clara.
- La novedad se reportó tarde.
- No hay firma/PIN/GPS.

Mensaje:

**“Cada entrega debe cerrar con evidencia verificable, no con una foto perdida en un chat.”**

### Dolor 3: Costos ocultos

Síntoma:

- Se sabe cuánto se facturó, pero no cuánto costó realmente operar.
- No se separan viáticos, flete, gastos, transportador, ruta, bodega, demora.
- No se ve margen por cliente.

Mensaje:

**“No puedes mejorar una operación cuyo margen no puedes ver.”**

### Dolor 4: Conductores y transportadores difíciles de controlar

Síntoma:

- Asignación manual.
- Disponibilidad poco clara.
- Estados atrasados.
- Liquidaciones discutidas.
- Gastos sin soporte.

Mensaje:

**“KargaX pone al conductor dentro del sistema: viaje, evidencia, gastos, novedades y liquidación quedan asociados a una operación.”**

### Dolor 5: Bodega desconectada de transporte

Síntoma:

- Inventario en un lado.
- Despacho en otro.
- Ruta en otro.
- Entrega en otro.
- Cliente llamando por estado.

Mensaje:

**“KargaX conecta bodega, despacho y entrega para que la operación no se rompa al salir del muelle.”**

### Dolor 6: Reportes insuficientes para decidir

Síntoma:

- Reportes manuales al final de la semana.
- No hay vista de incidencias.
- No hay ranking de proveedores/transportadores.
- No hay control de puntualidad.

Mensaje:

**“KargaX le da al gerente una vista ejecutiva de operación: rutas activas, cierres, novedades, costos y desempeño.”**

## Sectores con mayor oportunidad

### 1. Distribución regional

Por qué:

- Muchas rutas.
- Mucha evidencia.
- Decisiones rápidas.
- Menos burocracia que corporativos grandes.

Dolor:

- Despachos diarios, costos por ruta, entregas fallidas, soporte al cliente.

Módulo KargaX:

- Rutas + POD + reportes.

### 2. Operadores logísticos medianos

Por qué:

- Venden confianza, pero operan con herramientas fragmentadas.
- Necesitan diferenciarse frente a clientes.

Dolor:

- Multi-cliente, SLA, reportes y evidencias.

Módulo:

- 3PL + bodegas + control tower + evidencia.

### 3. Empresas con flota propia

Por qué:

- Pueden usar KargaX sin depender de marketplace.
- El decisor ve rápido el ROI.

Dolor:

- Conductores, viáticos, rutas, evidencia, gastos.

Módulo:

- Flota privada + wallet/ledger + evidencia.

### 4. Alimentos y bebidas no alcohólicas

Por qué:

- Entregas frecuentes.
- Ventanas de tiempo.
- Distribución regional.
- Rechazos y devoluciones.

Dolor:

- Puntualidad, evidencia, novedades y rutas.

Módulo:

- Última milla B2B + evidencias + reportes.

### 5. Ferretería, construcción y materiales

Por qué:

- Carga pesada o delicada.
- Alto costo de una entrega fallida.
- Clientes B2B exigentes.

Dolor:

- Daños, rechazos, entregas parciales, prueba de entrega.

Módulo:

- POD + fotos + gestión de novedades.

### 6. Farma e insumos médicos

Por qué:

- Alta exigencia de trazabilidad.
- Evidencia crítica.
- Costo reputacional de errores.

Dolor:

- Cumplimiento, rutas, evidencias y auditoría.

Módulo:

- Evidencia digital + tracking + reportes.

## Oportunidad SaaS

KargaX puede capturar valor en tres capas:

### Capa 1: Control operativo

Quién compra:

- Gerente de operaciones.
- Jefe de logística.
- Dueño de transportadora.
- Jefe de bodega.

Qué compra:

- Visibilidad de rutas.
- Evidencia.
- Novedades.
- Conductores.

### Capa 2: Control financiero

Quién compra:

- Gerente general.
- CFO.
- Dueño.

Qué compra:

- Costo por ruta.
- Margen por cliente.
- Liquidaciones.
- Pagos.
- Reportes.

### Capa 3: Red/marketplace

Quién compra:

- Empresas que necesitan capacidad externa.
- Operadores con demanda variable.

Qué compra:

- Publicación de cargas.
- Aplicaciones.
- Capacidad flexible.
- Trazabilidad.

## Qué no conviene vender todavía

No liderar con:

- “Somos el Uber de carga” únicamente.
- “Reemplazamos tu ERP”.
- “Tenemos todos los transportadores del país”.
- “Somos una pasarela financiera”.
- “Automatizamos toda tu operación de inmediato”.

Liderar con:

**“Tomemos una ruta, una bodega o una flota pequeña durante 15 a 30 días. Medimos evidencia, tiempos, novedades y costo operativo. Si hay valor, escalamos.”**

## Mensaje ganador del mercado

**“La mayoría de empresas no pierde dinero porque no tenga camiones. Pierde dinero porque no tiene control: rutas sin visibilidad, evidencias perdidas, costos ocultos, conductores por WhatsApp y reportes manuales. KargaX organiza esa operación en un solo sistema.”**
