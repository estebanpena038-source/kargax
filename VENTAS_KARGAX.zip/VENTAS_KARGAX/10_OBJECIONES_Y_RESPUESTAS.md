# 10_OBJECIONES_Y_RESPUESTAS

## Principio de manejo de objeciones

No pelees. Aterriza la objeción al piloto.

| Objeción | Respuesta recomendada |
|---|---|
| Ya usamos WhatsApp y Excel. | Sí, y esa es la realidad de muchas operaciones. KargaX no busca eliminar WhatsApp el día uno; busca que la información crítica no dependa de chats: evidencia, ruta, estado, novedad y costo quedan centralizados. |
| No tenemos presupuesto. | Lo entiendo. Por eso no propongo un contrato grande. Propongo un piloto limitado para medir si el desorden actual está costando más que la herramienta. |
| Ya tenemos un software. | Perfecto. KargaX puede funcionar como capa operativa para evidencias, conductores, rutas y novedades. No tiene que reemplazar su sistema actual en el piloto. |
| Nuestros conductores no van a usarlo. | El piloto debe probar eso con pocos conductores. El flujo se diseña simple: ver viaje, actualizar estado, subir evidencia y reportar novedad. |
| No queremos cambiar procesos. | No hay que cambiar toda la operación. Probamos en una ruta o bodega donde hoy exista dolor claro. |
| Necesitamos integraciones. | Tiene sentido a futuro. Para piloto no empezaría por integración; primero validamos valor operativo con carga manual o archivo simple. |
| Somos muy pequeños. | Justamente por eso puede servir. Si crecen operando con WhatsApp y Excel, el desorden crece con ustedes. |
| Somos muy grandes. | Entonces no intentemos toda la empresa. Tomemos una regional, una bodega, una línea o una flota específica. |
| Mándeme información. | Claro. Le envío un resumen de una página, pero para saber si aplica necesito entender su operación. ¿Le parece una llamada de 15 minutos? |
| Lo reviso internamente. | Perfecto. ¿Quién más debe verlo? Le propongo una reunión corta con esa persona y definimos si hay piloto o no. |
| Eso lo puede hacer mi equipo. | Sí, pero la pregunta es cuánto tiempo les cuesta y qué tan confiable queda la evidencia. KargaX reduce dependencia de seguimiento manual. |
| No queremos pagar piloto. | Podemos hacer piloto gratuito si el alcance es pequeño y hay sponsor interno. Si requiere configuración y acompañamiento, conviene piloto pago descontable del primer mes. |
| El mercado está lleno de software logístico. | Sí. La diferencia de KargaX es que ataca operación real: rutas, flota, bodega, evidencia, gastos, novedades y reportes en un flujo conectado. |
| ¿Tienen clientes? | Estamos en fase de pilotos founder-led. Por eso el alcance es controlado, con acompañamiento directo y métricas claras antes de vender un contrato grande. |
| ¿Qué pasa si falla? | Por eso se prueba en una parte limitada de la operación. No tocamos el core completo hasta demostrar estabilidad y valor. |
| ¿Quién da soporte? | Durante los primeros pilotos, soporte directo del fundador y canal operativo definido. Para plan pago se acuerda nivel de soporte según plan. |
| ¿Es seguro? | El producto está diseñado con roles, permisos y RLS en Supabase. Para datos sensibles, el piloto puede limitar información y luego revisar requisitos de compliance. |
| ¿Manejan pagos reales? | KargaX maneja ledger operativo y flujo de liquidación. Los movimientos/custodia de fondos reales deben hacerse con pasarelas o aliados regulados. |
| ¿Cuánto tarda implementar? | Un piloto simple puede configurarse con rutas, usuarios y conductores en pocos pasos. No requiere integración inicial. |
| No es prioridad ahora. | Entiendo. ¿Qué tendría que pasar para que sí sea prioridad: reclamos, evidencias, costos, retrasos o crecimiento de rutas? |

## Cierres recomendados

### Cierre suave

> Tiene sentido. Para reducir riesgo, probemos en una operación pequeña y medimos. Si no genera valor, no seguimos.

### Cierre de dolor

> El costo no está en el software. Está en evidencias perdidas, rutas sin visibilidad, llamadas, reprocesos y clientes reclamando.

### Cierre de piloto

> No le estoy pidiendo un contrato anual. Le propongo una prueba controlada con una métrica clara y fecha de decisión.

### Cierre ejecutivo

> Si al final del piloto usted no tiene más visibilidad, mejor evidencia y menos seguimiento manual, no tiene sentido seguir. Si sí lo tiene, el plan mensual se justifica solo.
