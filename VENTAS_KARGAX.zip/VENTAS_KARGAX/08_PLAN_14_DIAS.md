# 08_PLAN_14_DIAS

## Objetivo

Conseguir los primeros pilotos de KargaX en 14 días como founder joven trabajando solo.

## Reglas del plan

- Contactar todos los días hábiles.
- No perseguir leads fríos infinitamente.
- Priorizar empresas con dolor claro y decisión cercana.
- Usar WhatsApp para empresas medianas/regionales y LinkedIn/email para cargos corporativos.
- Cada respuesta debe llevar a una llamada, demo o cierre de piloto.
- Todo debe registrarse en el CRM.

| Día | Qué hacer | Empresas a contactar | Canal | Qué medir | Mensaje | Cómo registrar |
|---|---|---:|---|---|---|---|
| 1 | Definir oferta y preparar activos | 0 | Interno | Pitch 30s, demo mínima, lista de 50 leads, CRM listo | No contactar todavía; preparar mensaje por segmento | CRM con columnas completas y estados |
| 2 | Contactar primera ola Alta prioridad | 20 | WhatsApp + LinkedIn | Mensajes enviados, respuestas, interesados | Mensaje empresa distribución/flota | Registrar estado: Contactado / Respondió / Reunión |
| 3 | Segunda ola + seguimiento a interesados | 20 nuevos + seguimiento a día 2 | WhatsApp + email | Tasa de respuesta y reuniones pedidas | Seguimiento 1 | Marcar próximo paso con fecha |
| 4 | Llamadas cortas a leads que respondieron | 10 llamadas | Teléfono/WhatsApp | Dolores detectados, decisor, urgencia | Guion llamada | Notas de dolor exactas |
| 5 | Agendar demos y enviar contexto | 10 nuevos + 5 reuniones pedidas | LinkedIn + WhatsApp | Demos agendadas | Mensaje pedir reunión | Estado: Reunión agendada |
| 6 | Realizar primeras demos | 3 a 5 demos | Google Meet / presencial | Dolor, alcance posible, sponsor | Guion demo | Registrar objeciones y métricas |
| 7 | Diseñar pilotos personalizados | 0-5 nuevos | WhatsApp/email | Propuestas enviadas | Mensaje después demo | Crear ficha piloto por empresa |
| 8 | Nueva ola de leads regionales | 25 | WhatsApp + LinkedIn | Respuestas por ciudad/sector | Mensaje personalizado por sector | CRM actualizado |
| 9 | Seguimiento fuerte a demos | 0 nuevos + seguimiento | WhatsApp/email | Pilotos aceptados, LOI pedido | Mensaje LOI / cerrar piloto | Estado: Piloto propuesto |
| 10 | Hacer demos pendientes | 3 a 5 demos | Meet/presencial | Pilotos listos para cerrar | Guion demo | Registrar decisor y bloqueos |
| 11 | Cerrar primer piloto | 5 conversaciones calientes | WhatsApp/llamada | Sí/no, fecha de inicio, sponsor | Mensaje cerrar piloto | Estado: Piloto cerrado |
| 12 | Preparar onboarding piloto | 0 nuevos | Interno + cliente | Usuarios, rutas, conductores, métrica | Checklist piloto | Tareas y dueños |
| 13 | Empujar LOI/compromiso pago | Leads en negociación | WhatsApp/email | LOI, piloto pago o reunión final | Mensaje LOI | Estado: LOI solicitado |
| 14 | Revisión, pipeline y siguiente sprint | 10 follow-ups finales | WhatsApp/email | Número de pilotos, próximos pasos, bloqueos | Seguimiento 2 | Dashboard simple: contactados, respuestas, reuniones, pilotos |

## Cadencia de seguimiento

- Día 0: mensaje inicial.
- Día 2: seguimiento 1 con dolor concreto.
- Día 5: seguimiento 2 con piloto.
- Día 9: cierre elegante.
- Día 14: reactivación solo si hubo interés.

## Estados del CRM

- Nuevo.
- Contactado.
- Respondió.
- Calificado.
- Reunión agendada.
- Demo realizada.
- Piloto propuesto.
- Piloto cerrado.
- LOI solicitado.
- No interesado.
- Recontactar después.

## Métricas mínimas

- Contactados por día.
- Respuestas.
- Tasa de respuesta.
- Reuniones agendadas.
- Demos hechas.
- Pilotos propuestos.
- Pilotos cerrados.
- Motivos de rechazo.
- Dolor dominante por sector.

## Objetivo realista para founder solo

En 14 días:

- 150 a 220 contactos.
- 20 a 35 respuestas.
- 8 a 12 reuniones.
- 3 a 5 pilotos propuestos.
- 1 a 3 pilotos cerrados.

## Script diario de trabajo

Mañana:

- Buscar 10-20 leads.
- Enviar mensajes.
- Registrar en CRM.

Mediodía:

- Responder interesados.
- Pedir reunión.
- Confirmar demos.

Tarde:

- Hacer llamadas/demos.
- Enviar resumen.
- Pedir piloto/LOI.

Noche:

- Actualizar CRM.
- Mejorar mensajes.
- Preparar siguiente día.

## Error que debes evitar

No hacer “networking”. Hacer ventas.

Cada conversación debe terminar en:

- No aplica.
- Agendamos demo.
- Definimos piloto.
- Pedimos LOI.
- Recontacto con fecha.
