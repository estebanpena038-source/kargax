# 04_LISTA_LEADS

Fecha: 2026-06-12

## Nota de integridad

- No inventé correos, teléfonos ni nombres de personas.
- Cuando no hay contacto público confirmado en esta investigación, aparece **No encontrado** en el CSV.
- La columna **Fuente** contiene la fuente pública usada para cada lead.
- La lista prioriza empresas relacionadas con logística, transporte, distribución, inventario, bodegas, ecommerce, alimentos, materiales, farma/insumos y operación B2B.
- Para ejecución real, el siguiente paso es enriquecer cada lead manualmente con LinkedIn Sales Navigator, cámaras de comercio, páginas de contacto y llamadas a conmutador.

## Resumen por prioridad

- Alta: empresas con dolor claro, posible entrada por piloto y menor fricción.
- Media: empresas con fit fuerte pero ciclo de venta más largo o mayor complejidad.
- Baja: empresas muy maduras tecnológicamente, institucionales o potencialmente partners/competidores.

## Leads

| Empresa | Ciudad | Sector | Dolor probable | Módulo | Prioridad | Fuente |
| --- | --- | --- | --- | --- | --- | --- |
| TCC | Medellín / operación nacional | Transporte, mensajería y logística | Alta coordinación de rutas, evidencia de entrega, trazabilidad y liquidaciones operativas entre múltiples ciudades. | Evidencia digital + tracking + reportes operativos | Media | https://www.tcc.com.co/ |
| Coordinadora | Medellín / operación nacional | Transporte, paquetería, logística y ecommerce | Seguimiento de entregas, integración de operación ecommerce y control de novedades. | Marketplace + POD + soporte operativo | Media | https://www.coordinadora.com/ |
| Servientrega | Bogotá / operación nacional | Logística, mensajería y soluciones empresariales | Trazabilidad de entregas, soporte, evidencia digital y control de novedades. | POD + soporte + reportes | Media | https://www.servientrega.com/ |
| Envía | Medellín / operación nacional | Transporte de paquetes y carga | Control de despachos, aplicaciones, pagos y evidencias por viaje. | Marketplace + evidencia + wallet/liquidaciones | Media | https://www.envia.co/ |
| Inter Rapidísimo | Bogotá / operación nacional | Mensajería, paquetería y logística | Trazabilidad, prueba de entrega, gestión de novedades y reportes. | Evidencia digital + notificaciones + soporte | Media | https://www.interrapidisimo.com/ |
| Redetrans | Bogotá / operación nacional | Transporte de carga y logística | Control de manifiestos, ruta, evidencia, costos y estado de entregas. | Manifiesto + POD + reportes | Alta | https://www.redetrans.com.co/ |
| Saferbo | Medellín / operación nacional | Transporte de carga | Despacho, rastreo, evidencia, asignación y novedades de carga. | Control de viajes + evidencia + soporte | Alta | https://www.saferbo.com/ |
| Almaviva | Bogotá / operación nacional | Operador logístico, almacenamiento y comercio exterior | Control de bodegas, inventario, citas, despachos y trazabilidad entre almacén y transporte. | Bodegas + inventario + despachos | Media | https://www.almaviva.com.co/ |
| Suppla | Bogotá / operación nacional | 3PL, logística y supply chain | Operación multi-cliente, reportes, bodegas, trazabilidad y control de SLA. | 3PL multi-cliente + control tower + bodegas | Media | https://www.suppla.com/ |
| Blu Logistics | Bogotá / operación nacional | Operador logístico y comercio exterior | Trazabilidad internacional/nacional, coordinación entre bodegas, transporte y clientes. | Control tower + reportes + trazabilidad | Media | https://www.blulogistics.com/ |
| Open Market | Cali / Bogotá | Operador logístico, distribución y servicios de almacenamiento | Control de distribución, inventario, evidencias, rutas y novedades. | Bodegas + rutas + POD | Alta | https://www.openmarket.com.co/ |
| Ransa Colombia | Bogotá / Cali | 3PL, almacenamiento y distribución | Control multi-cliente, inventario, despacho, evidencia y reportes. | 3PL + bodegas + analítica | Media | https://www.ransa.biz/ |
| Ditransa | Medellín / operación nacional | Transporte de carga y logística | Asignación, control de rutas, trazabilidad, evidencias y costos de viaje. | Control de viajes + flota + reportes | Alta | https://www.ditransa.com.co/ |
| Transportes Sánchez Polo | Barranquilla / operación nacional | Transporte y logística | Visibilidad de carga, trazabilidad, control de conductores y soportes de entrega. | Flota privada + POD + reportes | Alta | https://www.sanchezpolo.com/ |
| Transportes Vigía | Bogotá / operación nacional | Transporte de carga | Seguimiento de viajes, novedades, evidencia y control de vehículos. | Tracking + flota + evidencia | Alta | https://www.vigialtda.com/ |
| Transportes Iceberg | Bogotá / operación nacional | Transporte refrigerado y cadena de frío | Control de ventanas de entrega, evidencia, novedades y trazabilidad crítica. | Evidencia + tracking + reportes por ruta | Alta | https://www.transportesiceberg.com/ |
| Mensajeros Urbanos | Bogotá / operación nacional | Última milla y entregas urbanas | Control de entregas, SLA, evidencia, novedades y soporte. | Última milla + POD + soporte | Media | https://mensajerosurbanos.com/ |
| Liftit | Bogotá / operación LatAm | Tecnología logística y transporte de carga | Eficiencia de flota, matching, tracking, pagos y experiencia de cliente. | Marketplace + wallet + control de evidencias | Baja | https://liftit.co/ |
| Cargamos | Bogotá / operación nacional | Logística y entregas | Evidencia, control de entregas, reportes y gestión de transportadores. | POD + tracking + marketplace | Baja | https://cargamos.com/ |
| Deprisa | Bogotá / operación nacional | Mensajería, carga y soluciones de entrega | Trazabilidad, evidencia y coordinación de entregas B2B. | Evidencia + soporte + reportes | Media | https://www.deprisa.com/ |
| 4-72 | Bogotá / operación nacional | Servicios postales, paquetería y logística | Visibilidad operativa, soporte, trazabilidad y evidencia de entregas. | POD + reportes + soporte | Baja | https://www.4-72.com.co/ |
| Colombina | Cali / Valle del Cauca | Alimentos, distribución y consumo masivo | Distribución nacional, evidencias, control de rutas, devoluciones y soporte a clientes. | Flota privada + evidencia + reportes | Alta | https://www.colombina.com/ |
| Harinera del Valle | Cali / Valle del Cauca | Alimentos y distribución | Despachos regionales, control de entregas, evidencia y costos de transporte. | Rutas + POD + control de costos | Alta | https://www.harinadelvalle.com/ |
| Tecnoquímicas | Cali / Jamundí / Valle del Cauca | Consumo masivo, cuidado personal e insumos médicos | Trazabilidad, cumplimiento, evidencia de entrega, bodegas y distribución nacional. | Bodegas + evidencia + control tower | Alta | https://www.tecnoquimicas.com/ |
| Carvajal Empaques | Cali / operación nacional | Empaques industriales y distribución B2B | Despachos B2B, evidencia, coordinación con transportadores y control de costos. | Bodegas + despacho + evidencia | Alta | https://www.carvajalempaques.com/ |
| Manuelita | Palmira / Valle del Cauca | Agroindustrial y distribución | Transporte regional/nacional, costos de ruta, coordinación y evidencias. | Flota privada + costos + evidencia | Alta | https://www.manuelita.com/ |
| Incauca | Miranda / Cauca | Agroindustria y distribución | Coordinación de carga, rutas regionales, costos, evidencias y trazabilidad. | Rutas + flota privada + reportes | Alta | https://www.incauca.com/ |
| Ingenio La Cabaña | Guachené / Cauca | Agroindustria y distribución | Transporte regional, evidencias, costos y coordinación operativa. | Flota privada + costos + evidencia | Alta | https://www.ingeniolacabana.com/ |
| Ingredion Colombia | Cali / Valle del Cauca | Ingredientes alimentarios e industria B2B | Despachos B2B, trazabilidad, evidencia y coordinación con transportadoras. | Bodegas + despacho + POD | Media | https://www.ingredion.com/sa/es-co.html |
| Alquería | Bogotá / Cundinamarca | Alimentos y distribución refrigerada | Ventanas de entrega, control de ruta, evidencias y devoluciones. | Última milla B2B + evidencia + novedades | Alta | https://www.alqueria.com.co/ |
| Alpina | Sopó / Bogotá | Alimentos, distribución y cadena de frío | Control de rutas, tiempos, evidencias y novedades en distribución. | Tracking + evidencia + reportes | Media | https://www.alpina.com/ |
| Grupo Nutresa | Medellín / operación nacional | Alimentos y distribución | Multiempresa, distribución nacional, evidencia, costos y control de operación. | CEO control tower + rutas + reportes | Media | https://gruponutresa.com/ |
| Grupo Éxito | Medellín / Bogotá / operación nacional | Retail, supermercados y distribución | Bodegas, última milla, rutas, evidencia, proveedores y tiendas. | Bodegas + despacho + evidencia | Media | https://www.grupoexito.com.co/ |
| Olímpica | Barranquilla / operación nacional | Retail, supermercados y distribución | Distribución a tiendas, evidencia, control de rutas y novedades. | Rutas + POD + bodegas | Alta | https://www.olimpica.com/ |
| Farmatodo Colombia | Bogotá / operación nacional | Retail farmacéutico y distribución | Entregas rápidas, evidencia, cumplimiento de tiempos y soporte. | Última milla + evidencia + soporte | Media | https://www.farmatodo.com.co/ |
| Cruz Verde | Bogotá / operación nacional | Retail farmacéutico y distribución | Evidencias de entrega, rutas a puntos de venta, trazabilidad y novedades. | POD + rutas + reportes | Media | https://www.cruzverde.com.co/ |
| Audifarma | Pereira / operación nacional | Servicios farmacéuticos y distribución | Trazabilidad de entregas, evidencia, soporte y control de rutas regionales. | Evidencia + tracking + reportes | Alta | https://www.audifarma.com.co/ |
| Copservir / La Rebaja | Cali / operación nacional | Retail farmacéutico y distribución | Distribución a puntos de venta, evidencias, rutas y novedades. | Rutas + POD + soporte | Alta | https://www.larebajavirtual.com/ |
| Distraves | Bucaramanga / Santander | Alimentos y distribución | Distribución refrigerada, evidencia, control de rutas y cumplimiento. | Tracking + evidencia + reportes | Alta | https://www.distraves.com/ |
| Frisby | Pereira / operación nacional | Alimentos, restaurantes y distribución | Abastecimiento de puntos, entregas, rutas, evidencia y coordinación regional. | Bodegas + rutas + evidencia | Alta | https://frisby.com.co/ |
| Avidesa Mac Pollo | Bucaramanga / Santander | Alimentos y distribución | Control de rutas, tiempos, evidencias y novedades en distribución de alimentos. | Tracking + evidencia + control de flota | Alta | https://www.macpollo.com/ |
| Homecenter / Sodimac Colombia | Bogotá / operación nacional | Retail construcción, hogar y materiales | Entregas de materiales, coordinación con clientes, evidencias y costos de última milla. | Última milla B2B/B2C + evidencia | Media | https://www.homecenter.com.co/ |
| Corona | Bogotá / Medellín / operación nacional | Materiales de construcción y hogar | Despachos B2B, evidencia, daños, devoluciones y coordinación con transportadores. | POD + control de daños/novedades + reportes | Media | https://www.corona.co/ |
| Cemex Colombia | Bogotá / operación nacional | Materiales de construcción | Rutas, entregas, costos de transporte, cumplimiento y evidencia. | Control de rutas + costos + POD | Media | https://www.cemexcolombia.com/ |
| Cementos Argos | Medellín / operación nacional | Materiales de construcción | Control de entregas, rutas, costos, evidencia y coordinación con clientes B2B. | Control de flota + reportes + POD | Media | https://argos.co/ |
| Acerías PazdelRío | Bogotá / Boyacá | Acero, materiales e industria B2B | Despachos B2B, trazabilidad, evidencias y control de costos. | Despacho + evidencia + margen/costos | Media | https://www.pazdelrio.com.co/ |
| Sumatec | Medellín / operación nacional | Suministros industriales y distribución B2B | Entregas B2B, inventario, rutas, evidencia y coordinación con clientes industriales. | Bodegas + rutas + evidencia | Alta | https://www.sumatec.co/ |
| Mundial de Tornillos | Cali / Bogotá / operación nacional | Ferretería e insumos industriales | Distribución a clientes B2B, inventario, evidencia de entrega y coordinación. | Bodegas + entregas + POD | Alta | https://www.mundialdetornillos.com/ |
| Mercado Libre Colombia | Bogotá / operación nacional | Marketplace y ecommerce | Última milla, entregas, evidencias, transportadores y SLA. | Marketplace logístico + evidencia + reportes | Baja | https://www.mercadolibre.com.co/ |
| Rappi | Bogotá / operación nacional | Marketplace y última milla | Control de entregas, SLA, soporte, evidencia y operación multi-ciudad. | Última milla + soporte + analítica | Baja | https://www.rappi.com.co/ |
| Agrocampo | Bogotá / operación nacional | Retail agropecuario, ecommerce y distribución | Entregas ecommerce/B2B, inventario, rutas, evidencia y devoluciones. | Bodegas + última milla + evidencia | Alta | https://www.agrocampo.com.co/ |
| Frubana | Bogotá / operación nacional | B2B alimentos, marketplace y distribución | Distribución B2B de alimentos, control de rutas, evidencia y cumplimiento. | Última milla B2B + evidencia + costos | Media | https://www.frubana.com/ |


## Cómo usar esta lista

1. Empieza por los leads Alta en Cali, Valle, Cauca, Bucaramanga, Pereira y Barranquilla.
2. Contacta por WhatsApp/conmutador cuando sea empresa mediana o regional.
3. Para corporativos grandes, usa LinkedIn + email + referido + evento/logística.
4. Nunca abras vendiendo “software”. Abre con un dolor:
   - evidencias perdidas
   - rutas sin visibilidad
   - costos ocultos
   - conductores por WhatsApp
   - bodegas desconectadas del despacho
5. Cierra siempre con piloto, no con contrato anual.
