# 07_MENSAJES_OUTBOUND

## Reglas de estilo

- Corto.
- Humano.
- Directo.
- Sin sonar desesperado.
- Hablar de dolor real.
- Cerrar con una acción concreta.
- No decir “app”.
- No prometer magia.
- No mandar párrafos largos.

---

## 1. Mensaje para empresa logística

Hola {{Nombre}}, soy {{Tu nombre}}, fundador de KargaX.

Estamos ayudando a empresas logísticas a controlar rutas, conductores, evidencias, novedades y costos desde una sola plataforma.

Vi que {{Empresa}} maneja operación logística. ¿Tiene sentido mostrarle un piloto corto para centralizar evidencias y control de viajes en 15 días?

---

## 2. Mensaje para empresa de distribución

Hola {{Nombre}}, vi que {{Empresa}} maneja distribución y entregas.

KargaX ayuda a que cada ruta tenga conductor, estado, evidencia, novedad y costo visible, sin depender de WhatsApp y Excel.

¿Le puedo mostrar un flujo de piloto con una ruta real?

---

## 3. Mensaje para ferretería grande

Hola {{Nombre}}, soy {{Tu nombre}}, fundador de KargaX.

En ferretería/materiales, una entrega mal controlada puede terminar en reclamo, reproceso o pérdida de evidencia.

KargaX ayuda a controlar despachos, fotos, firma, novedades y rutas desde una sola plataforma.

¿Tiene sentido revisar un piloto de 15 días?

---

## 4. Mensaje para ecommerce

Hola {{Nombre}}, vi que {{Empresa}} vende productos físicos y maneja entregas.

KargaX puede ayudarles a controlar lo que pasa después de la venta: despacho, ruta, evidencia, novedad y estado de entrega.

¿Le puedo mostrar un piloto para mejorar visibilidad operativa?

---

## 5. Mensaje para empresa con flota

Hola {{Nombre}}, soy {{Tu nombre}}, fundador de KargaX.

KargaX ayuda a empresas con flota propia a controlar conductores, rutas, gastos, evidencias y novedades sin operar todo por WhatsApp.

¿Tiene sentido que le muestre un piloto con 3 a 5 conductores?

---

## 6. Mensaje para gerente de operaciones

Hola {{Nombre}}, sé que operaciones suele vivir apagando incendios: conductores, rutas, evidencias, clientes preguntando y novedades.

KargaX centraliza ese flujo para que el equipo tenga control real de cada viaje.

¿Le puedo mostrar el flujo en 20 minutos?

---

## 7. Mensaje para dueño o CEO

Hola {{Nombre}}, soy {{Tu nombre}}, fundador de KargaX.

Estamos resolviendo un problema muy concreto: empresas que mueven mercancía pero pierden dinero por falta de visibilidad, evidencias perdidas, rutas mal controladas y costos ocultos.

Me gustaría mostrarle un piloto corto para medir control operativo en una ruta o flota pequeña.

---

## 8. Mensaje para LinkedIn

Hola {{Nombre}}, vi tu rol en {{Empresa}}. Estoy construyendo KargaX, una plataforma para controlar rutas, conductores, evidencias, bodegas y costos logísticos.

Estoy abriendo 3 pilotos founder-led con empresas que tengan operación real. ¿Tiene sentido conversar?

---

## 9. Seguimiento 1

Hola {{Nombre}}, le escribo de nuevo porque creo que KargaX puede aplicar muy bien a {{Empresa}}.

La idea no es cambiar toda su operación. Es probar con una ruta, bodega o flota pequeña y medir evidencia, visibilidad y novedades.

¿Le queda bien una llamada corta esta semana?

---

## 10. Seguimiento 2

Hola {{Nombre}}, cierro el ciclo por ahora.

Si en {{Empresa}} están buscando mejorar control de rutas, evidencias de entrega, conductores o costos logísticos, KargaX puede ayudarles con un piloto pequeño y medible.

¿Le parece si lo dejamos para una conversación de 20 minutos?

---

## 11. Mensaje para pedir reunión

{{Nombre}}, por lo que vi, {{Empresa}} tiene una operación donde la trazabilidad y la evidencia pueden generar impacto.

Le propongo algo simple: 20 minutos, le muestro el flujo y revisamos si aplica para un piloto. ¿Le sirve {{día}} a las {{hora}}?

---

## 12. Mensaje después de demo

Gracias por el espacio, {{Nombre}}.

Por lo que hablamos, el dolor principal parece ser {{dolor}}. Mi recomendación es no intentar implementar todo, sino probar KargaX en {{alcance}} durante {{duración}}.

Mediríamos:
1. evidencias completas
2. tiempo de actualización
3. novedades
4. visibilidad para gerencia

¿Avanzamos con el piloto?

---

## 13. Mensaje para pedir LOI

{{Nombre}}, si KargaX demuestra en el piloto que puede mejorar {{dolor específico}}, me gustaría que dejemos firmado un LOI simple.

No es un contrato largo. Solo deja claro que, si cumplimos las métricas del piloto, {{Empresa}} tiene intención de avanzar a un plan pago.

¿Le parece si le envío un borrador de una página?

---

## 14. Mensaje para cerrar piloto

{{Nombre}}, para mantenerlo concreto:

Propongo piloto de {{15/30}} días con {{alcance}}.

Incluye configuración, acompañamiento, evidencia de entrega, novedades, control de rutas y reporte final.

Métrica principal: {{métrica}}.

Si funciona, pasamos a plan mensual. Si no genera valor, cerramos el piloto sin seguir.

¿Lo activamos esta semana?

---

# Mensajes ultra cortos para WhatsApp

## Versión 1

Hola {{Nombre}}, ¿quién ve logística/operaciones en {{Empresa}}? Estoy validando KargaX, una plataforma para controlar rutas, conductores, evidencias y costos. Creo que podría servirles.

## Versión 2

Hola {{Nombre}}, pregunta rápida: ¿hoy las evidencias de entrega de {{Empresa}} quedan centralizadas o siguen llegando por WhatsApp?

## Versión 3

Hola {{Nombre}}, estoy buscando 3 empresas con operación logística real para pilotos de KargaX. El foco es rutas, evidencia, novedades y costos. ¿Quién sería la persona correcta?

## Versión 4

Hola {{Nombre}}, no le quiero vender humo. KargaX se prueba con una ruta real durante 15 días. Si mejora visibilidad y evidencia, seguimos. ¿Le muestro?

---

# Mensaje de referido

Hola {{Nombre}}, ¿me podrías ayudar con una intro a alguien de operaciones/logística en {{Empresa}}?

Estoy construyendo KargaX para controlar rutas, conductores, evidencias, bodegas y costos. Busco empresas con operación real para pilotos serios de 15 a 30 días.

---

# Mensaje a conmutador o WhatsApp general

Hola, buenos días. ¿Me pueden indicar quién es la persona encargada de logística, distribución o transporte?

Soy fundador de KargaX y estoy proponiendo pilotos para empresas que necesitan controlar rutas, evidencias de entrega, conductores y novedades operativas.
