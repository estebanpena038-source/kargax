# 03_CLIENTE_IDEAL_ICP

## Prioridad estratégica

Para vender rápido, prioriza empresas con dolor visible y decisión cercana: **flota propia, distribución regional, operadores logísticos medianos y ferreterías/materiales**.

## ICP 1: Distribuidoras regionales

**Dolor principal:** Entregas diarias con evidencia dispersa y clientes preguntando estados.

**Módulo de KargaX que más le sirve:** Rutas, POD, novedades, reportes.

**Promesa de valor:** Controlar entregas, evidencias y costos sin perseguir al conductor por WhatsApp.

**Quién toma la decisión:** Dueño, gerente general, gerente de operaciones.

**A quién contactar primero:** Jefe de logística o coordinador de despachos.

**Objeción probable:** “Ya lo manejamos con WhatsApp y Excel.”

**Respuesta:** Precisamente: el piloto mide cuánto tiempo y cuántas evidencias se pierden por hacerlo así.

**Facilidad de venta:** Alto

**Prioridad recomendada:** 1

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.

## ICP 2: Operadores logísticos pequeños y medianos

**Dolor principal:** Necesitan entregar reportes a clientes, pero operan multi-cliente con procesos manuales.

**Módulo de KargaX que más le sirve:** Bodegas, 3PL, evidencias, control tower.

**Promesa de valor:** Diferenciarse con trazabilidad y reportes ejecutivos sin comprar un TMS/WMS pesado.

**Quién toma la decisión:** Gerente general, director de operaciones.

**A quién contactar primero:** Gerente de operaciones o comercial B2B.

**Objeción probable:** “Nuestro proceso es muy específico.”

**Respuesta:** Empezamos con un flujo, no con toda la operación. KargaX se valida por piloto controlado.

**Facilidad de venta:** Alto

**Prioridad recomendada:** 2

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.

## ICP 3: Ecommerce con entregas propias

**Dolor principal:** Última milla, entregas fallidas, soporte y falta de evidencia clara.

**Módulo de KargaX que más le sirve:** Última milla, POD, soporte, novedades.

**Promesa de valor:** Reducir reclamos y mejorar visibilidad de entregas con evidencia centralizada.

**Quién toma la decisión:** Head of Operations, Ecommerce manager, founder.

**A quién contactar primero:** Operations manager.

**Objeción probable:** “Ya tengo plataforma ecommerce.”

**Respuesta:** KargaX no reemplaza la tienda; controla lo que pasa después de vender: despacho, ruta y evidencia.

**Facilidad de venta:** Medio

**Prioridad recomendada:** 5

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.

## ICP 4: Alimentos y bebidas no alcohólicas

**Dolor principal:** Rutas frecuentes, ventanas de entrega, devoluciones y rechazos.

**Módulo de KargaX que más le sirve:** Rutas, POD, control de novedades, reportes.

**Promesa de valor:** Tener trazabilidad de cada entrega y novedad para reducir reprocesos.

**Quién toma la decisión:** Gerente de logística, gerente regional, director supply chain.

**A quién contactar primero:** Jefe de transporte/distribución.

**Objeción probable:** “Nuestros conductores no son tecnológicos.”

**Respuesta:** El flujo debe ser simple: aceptar viaje, subir evidencia, reportar novedad. Se acompaña en piloto.

**Facilidad de venta:** Alto

**Prioridad recomendada:** 3

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.

## ICP 5: Ferreterías, construcción y materiales pesados

**Dolor principal:** Entregas costosas, productos pesados/frágiles, rechazos, daños y clientes B2B exigentes.

**Módulo de KargaX que más le sirve:** POD, fotos, novedades, costos por ruta.

**Promesa de valor:** Evitar discusiones con clientes y controlar entregas costosas con evidencia clara.

**Quién toma la decisión:** Dueño, gerente de operaciones, gerente comercial B2B.

**A quién contactar primero:** Jefe de logística o despachos.

**Objeción probable:** “No tenemos tiempo para implementar.”

**Respuesta:** El piloto no requiere ERP: se carga una ruta real y se mide evidencia/cierre operativo.

**Facilidad de venta:** Alto

**Prioridad recomendada:** 4

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.

## ICP 6: Farma e insumos médicos

**Dolor principal:** Necesidad de trazabilidad, entrega correcta, evidencia y auditoría.

**Módulo de KargaX que más le sirve:** Tracking, POD, reportes, roles.

**Promesa de valor:** Tener evidencia verificable por entrega y control de incidentes en operación sensible.

**Quién toma la decisión:** Director de operaciones, compliance, logística.

**A quién contactar primero:** Coordinador de distribución.

**Objeción probable:** “Necesitamos seguridad y cumplimiento.”

**Respuesta:** El piloto se limita a datos operativos no sensibles y evidencia de flujo; luego se evalúa compliance.

**Facilidad de venta:** Medio

**Prioridad recomendada:** 6

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.

## ICP 7: Empresas con flota propia

**Dolor principal:** Conductores por WhatsApp, gastos sin soporte, rutas no auditadas.

**Módulo de KargaX que más le sirve:** Flota privada, viáticos, POD, wallet/ledger, reportes.

**Promesa de valor:** Controlar conductores propios, rutas, gastos y evidencias sin depender de marketplace.

**Quién toma la decisión:** Dueño, gerente general, gerente de operaciones.

**A quién contactar primero:** Jefe de flota/transporte.

**Objeción probable:** “Mis conductores ya saben qué hacer.”

**Respuesta:** No se trata de saber conducir; se trata de que la empresa pueda controlar costo, evidencia y estado.

**Facilidad de venta:** Alto

**Prioridad recomendada:** 1

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.

## ICP 8: Transportadoras tradicionales que quieren digitalizarse

**Dolor principal:** Operación manual, clientes piden trazabilidad y reportes, presión por competir.

**Módulo de KargaX que más le sirve:** Marketplace, aplicaciones, POD, reportes, wallet/ledger.

**Promesa de valor:** Verse como transportadora moderna sin construir software interno.

**Quién toma la decisión:** Dueño, gerente general, gerente comercial.

**A quién contactar primero:** Gerente de operaciones/comercial.

**Objeción probable:** “Eso suena caro.”

**Respuesta:** Más caro es perder clientes por falta de visibilidad. Piloto barato, medible y con alcance limitado.

**Facilidad de venta:** Alto

**Prioridad recomendada:** 2

**Mensaje inicial recomendado:**

> Hola {Nombre}, estoy construyendo KargaX para empresas que mueven mercancía y hoy pierden control por rutas, evidencias, conductores y costos dispersos. Creo que en una operación como la de {Empresa} podríamos hacer un piloto corto para medir trazabilidad, evidencia y novedades en 15 días. ¿Tiene sentido que le muestre el flujo?

**Cómo cerrar:**

> No le propongo cambiar su operación completa. Tomemos una ruta, una bodega o 5 conductores. Si en 15 días no vemos mejora en visibilidad, evidencias o control de novedades, no seguimos. Si funciona, escalamos por módulos.
